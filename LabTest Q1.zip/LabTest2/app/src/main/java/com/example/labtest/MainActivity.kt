package com.example.labtest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.text.TextUtils

import android.text.util.Linkify

import android.text.SpannableString

import android.text.Spannable

import android.text.method.LinkMovementMethod




class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val showButton1 = findViewById<Button>(R.id.btn1)
        val showButton2 = findViewById<Button>(R.id.btn2)

        // finding the edit text
        val editText1 = findViewById<EditText>(R.id.EditText1)
        val editText2 = findViewById<EditText>(R.id.EditText2)

        editText1.movementMethod = LinkMovementMethod.getInstance()

        val spannable: Spannable = SpannableString("http://www.google.com/")
        Linkify.addLinks(spannable, Linkify.WEB_URLS)

        val text1 = TextUtils.concat(spannable, "\u200B")

        editText1.setText(text1)
        // Setting On Click Listener
        showButton1.setOnClickListener {

            // Getting the user input
            val text1= editText1.text

            editText2.setText(text2)
            // Setting On Click Listener
            showButton2.setOnClickListener {

                // Getting the user input
                val text = editText2.text

                // Showing the user input
                Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
